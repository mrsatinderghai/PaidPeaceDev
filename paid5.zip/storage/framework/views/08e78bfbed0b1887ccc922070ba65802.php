<script>
	$(function() {
		$(".delete").on("submit", function(){
			return confirm("Do you want to delete this truck?");
		});
	});
</script>
	

<?php if(count($trucks) > 0): ?>
<table class="table table-condensed table-striped">
	<thead>
		<th>Name</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $trucks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr <?php if($truck->hidden): ?> class="bg-warning" <?php endif; ?>>
			<td><a href="<?php echo e(url('truck/'.$truck->id.'/edit')); ?>"><?php echo e($truck->name); ?> <?php if($truck->hidden): ?> <span class="text-danger">(Hidden)</span> <?php endif; ?></a></td>
			<td><a href="<?php echo e(route('truck.hide', $truck->id)); ?>" class="btn btn-default"><?php if($truck->hidden): ?> Un- <?php endif; ?> Hide From Schedule</a></td>
			<td>
					<form action="<?php echo e(url('truck/'.$truck->id)); ?>" method="POST" class="delete">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

		  
						<button class="btn btn-danger btn-xs">
						  <i class="fa fa-trash"></i>
						</button>
					  </form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php endif; ?>
<?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/trucks/list.blade.php ENDPATH**/ ?>