<?php $__env->startSection('content'); ?>

<div class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Create New User
                        </div>
                        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="panel-body">
                            <!-- New Team Form -->
                            <?php echo Form::open(array('class' => 'form-horizontal')); ?>

                            <div class="form-group">
                                <?php echo Form::label('name', 'Name', array('class' => 'col-sm-3 control-label')); ?>

                                <div class="col-sm-6">
                                    <?php echo Form::text('name', '', array('class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('email', 'Email', array('class' => 'col-sm-3 control-label')); ?>

                                <div class="col-sm-6">
                                    <?php echo Form::text('email', '', array('class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('password', 'Password', array('class' => 'col-sm-3 control-label')); ?>

                                <div class="col-sm-6">
                                    <?php echo Form::password('password', array('class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-3 label_display"></div>
                                <div class="col-sm-offset-3 col-sm-6 submit_btn_align">
                                    <?php echo Form::submit('Add User', array('class' => 'btn btn-primary')); ?>

                                </div>
                            </di>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>

                <?php if(count($users) > 0): ?>
                <div class="card">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Users
                        </div>

                        <div class="panel-body">
                            <table class="table table-striped task-table">

                                <!-- Table Headings -->
                                <thead>
                                    <th>User</th>
                                    <th>
                                        Team
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Roles
                                    </th>
                                    <th>&nbsp</th>
                                </thead>

                                <!-- Table Body -->
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <!-- Task Name -->
                                        <td class="table-text">
                                            <a href="<?php echo e(url('/user/'.$user->id)); ?>"><?php echo e($user->name); ?></a>
                                        </td>

                                        <td>
                                            <a href="<?php echo e(url('/team/'.$user->team_id)); ?>"></a>
                                        </td>
                                        <td>
                                            <?php echo e($user->email); ?>

                                        </td>
                                        <td>
                                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($role->name); ?>,&nbsp
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(url('user/'.$user->id)); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>


                                                <button class="btn btn-danger">
                                                    <i class="fa fa-trash"></i> Delete User
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/users/index.blade.php ENDPATH**/ ?>