<?php $__env->startSection('content'); ?>
<style type="text/css">
    .header-title {
    margin-left: 12px;
}
</style>
<div class="content-page">
    <div class="container-fluid Work_Order_Analyze">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">

    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title">Work Order Analyze</h4>
                        </div>
                    </div>

                    <div class="tab-content work_order_analyze" id="myTabContent-2">

                        <div class="row">
                            <div class="col-md-6">
                              
                            </div>
                            <div class="col-md-6 mt-2 d-flex justify-content-end">
                                <?php echo Form::open(['route' => 'work_order.analyze', 'class' => 'form-inline']); ?>

                                <div class="col-xs-12 col-md-5">
                                    <div class="form-group">
                                        <?php echo Form::label('from_date', 'From'); ?>

                                        <?php echo Form::date('from_date', null, ['class' => 'form-control']); ?>

                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-5">
                                    <div class="form-group">
                                        <?php echo Form::label('to_date', 'To'); ?>

                                        <?php echo Form::date('to_date', null, ['class' => 'form-control']); ?>

                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-2">
                                    <div class="form-group">
                                        <button class="btn btn-primary m-0">Filter</button>
                                    </div>
                                </div>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable-1" class="table data-table table-striped table-bordered">
                                    <thead>
                                        <th>Number</th>
                                        <th>Customer</th>
                                        <th>Created Date</th>
                                        <th>Appointment Date</th>
                                        <th>Completed On</th>
                                        <th>Zip Code</th>
                                        <th>Phone</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $work_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($wo->id); ?></td>
                                            <td><?php echo e($wo->customer->full_name()); ?></td>
                                            <td><?php echo e($wo->created_at); ?></td>
                                            <td><?php echo e($wo->appointment_date); ?></td>
                                            <td><?php echo e($wo->completed_on); ?></td>
                                            <td><?php echo e($wo->customer->zip); ?></td>
                                            <td><?php echo e($wo->customer->phone_number_formatter()); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Number</th>
                                            <th>Customer</th>
                                            <th>Created Date</th>
                                            <th>Appointment Date</th>
                                            <th>Completed On</th>
                                            <th>Zip Code</th>
                                            <th>Phone</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
    $('.delete-customer').click(function(e) {
        e.preventDefault() // Don't post the form, unless confirmed
        if (confirm('Are you sure?')) {
            // Post the form
            $(e.target).closest('form').submit() // Post the surrounding form
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/work_orders/analyze.blade.php ENDPATH**/ ?>