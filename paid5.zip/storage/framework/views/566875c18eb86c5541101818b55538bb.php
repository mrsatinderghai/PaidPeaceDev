<table id="datatable-1" class="table data-table table-striped table-bordered table-ajax" data-url='data/invoices'>
	<thead>
		<th>Date</th>
		<th>Customer</th>
		<th>Address</th>
		<th>Amount</th>
		<th>View</th>
		<th>Sent</th>
	</thead>
	<tbody>

	</tbody>
</table><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/invoices/send_list.blade.php ENDPATH**/ ?>