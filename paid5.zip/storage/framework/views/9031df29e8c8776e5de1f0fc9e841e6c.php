<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header d-flex justify-content-between">
            <div class="header-title">
              <h4 class="card-title">Customers list</h4>
            </div>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable-1" class="table data-table table-striped table-bordered">
                <thead>
                  <th><a href="<?php echo e(url('/customer/index/last_name')); ?>">Last Name</a></th>
                  <th><a href="<?php echo e(url('/customer/index/first_name')); ?>">First Name</a></th>
                  <th>Address</th>
                  <th>Address 2</th>
                  <th><a href="<?php echo e(url('/customer/index/city')); ?>">City</a></th>
                  <th><a href="<?php echo e(url('/customer/index/state')); ?>">State</a></th>
                  <th>Zip</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th><a href="<?php echo e(url('/customer/index/equipment_make')); ?>">Make</a></th>
                  <th><a href="<?php echo e(url('/customer/index/equipment_model')); ?>">Model</a></th>
                  <th>Edit</th>
                  <th>Delete</th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="clickable-row" data-href="<?php echo e(url('/customer/'.$customer->id.'/edit/')); ?>">
                    <td><?php echo e($customer->last_name); ?></td>
                    <td><?php echo e($customer->first_name); ?></td>
                    <td><?php echo e($customer->address1); ?></td>
                    <td><?php echo e($customer->address2); ?></td>
                    <td><?php echo e($customer->city); ?></td>
                    <td><?php echo e($customer->state); ?></td>
                    <td><?php echo e($customer->zip); ?></td>
                    <td><?php echo e($customer->phone_number_formatter()); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->equipment_make); ?></td>
                    <td><?php echo e($customer->equipment_model); ?></td>
                    <td>
                      <a href="<?php echo e(url('/customer/'.$customer->id.'/edit/')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                    <td>
                      <form action="<?php echo e(url('customer/'.$customer->id)); ?>" method="POST" class="delete">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>


                        <button class="btn btn-danger btn-xs">
                          <i class="fa fa-trash"></i>
                        </button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th><a href="<?php echo e(url('/customer/index/last_name')); ?>">Last Name</a></th>
                    <th><a href="<?php echo e(url('/customer/index/first_name')); ?>">First Name</a></th>
                    <th>Address</th>
                    <th>Address 2</th>
                    <th><a href="<?php echo e(url('/customer/index/city')); ?>">City</a></th>
                    <th><a href="<?php echo e(url('/customer/index/state')); ?>">State</a></th>
                    <th>Zip</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th><a href="<?php echo e(url('/customer/index/equipment_make')); ?>">Make</a></th>
                    <th><a href="<?php echo e(url('/customer/index/equipment_model')); ?>">Model</a></th>
                    <th>Edit</th>
                  <th>Delete</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>



<script>
  $(function() {
    $(".delete").on("submit", function() {
      return confirm("Do you want to delete this item?");
    });

    $(".clickable-row").click(function() {
      window.location = $(this).data("href");
    });

  });
</script>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten2\resources\views/customers/list.blade.php ENDPATH**/ ?>