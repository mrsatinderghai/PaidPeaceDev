<?php $__env->startSection('content'); ?>


<div class="content-page">
	<div class="container-fluid zip_code">
		<div class="row">
			<div class="col-sm-12">
				<div class="card">
					<div class="col-xs-12 col-md-12">
						<div class="row">
							<?php echo $__env->make('zip_code_areas.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/zip_code_areas/index.blade.php ENDPATH**/ ?>