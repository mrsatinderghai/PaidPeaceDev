<?php $__env->startSection('content'); ?>



<div class="content-page">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="iq-edit-list-data">
          <div class="tab-content">
            <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
              <div class="card">
                <div class="card-header d-flex justify-content-between">
                  <div class="header-title">
                    <h4 class="card-title">Personal Information</h4>
                  </div>
                </div>
                <div class="card-body">
                  <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <div class="panel-body">
                    <!-- New Team Form -->
                    <?php echo Form::model($user, array('route' => array('user.update', $user->id), 'method' => 'PATCH', 'class' => 'form-horizontal')); ?>

                    <div class="form-group">
                      <?php echo Form::label('name', 'Name', array('class' => 'col-sm-3 control-label')); ?>

                      <div class="col-sm-6">
                        <?php echo Form::text('name', $user->name, array('class' => 'form-control')); ?>

                      </div>
                    </div>
                    <div class="form-group">
                      <?php echo Form::label('email', 'Email', array('class' => 'col-sm-3 control-label')); ?>

                      <div class="col-sm-6">
                        <?php echo Form::text('email', $user->email, array('class' => 'form-control')); ?>

                      </div>
                    </div>
                    <div class="form-group">
                      <?php echo Form::label('password', 'New Password', array('class' => 'col-sm-3 control-label')); ?>

                      <div class="col-sm-6">
                        <?php echo Form::password('password', array('class' => 'form-control')); ?>

                        <!--             <?php echo Form::text('current_password', $user->password, array('class' => 'form-control')); ?> -->
                      </div>
                    </div>
                    <div class="form-group">
                      <?php echo Form::label('password_confirmation', 'Confirm Password', array('class' => 'col-sm-3 control-label')); ?>

                      <div class="col-sm-6">
                        <?php echo Form::password('password_confirmation', array('class' => 'form-control')); ?>

                      </div>
                    </div>
                    <div class="form-group" style="text-align: end;">
                      <div class="col-sm-offset-3 col-sm-9 remove_space">
                        <?php if(auth()->check()): ?>
                        <?php if(auth()->user()->isAdmin()): ?>
                        <?php echo Form::submit('Save', array('class' => 'btn btn-primary')); ?>

                        <?php endif; ?>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/user/')); ?>" class="btn btn-primary">Back</a>
                      </div>
                      <?php echo Form::close(); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten2\resources\views/users/edit.blade.php ENDPATH**/ ?>