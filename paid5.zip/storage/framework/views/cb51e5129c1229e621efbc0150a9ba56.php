<?php $__env->startSection('content'); ?>
<div class="content-page">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				
				<div class="card">

							 <div class="card-header d-flex justify-content-between">
            <div class="header-title">
              <h4 class="card-title"><?php echo e($title); ?></h4>
            </div>
          </div>

					<div class="col-xs-12 col-md-12 list">
						<?php echo $__env->make('invoices.send_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css" />
<script src='//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js'></script>
<script>
	var ajaxUrl = $('.table-ajax').attr('data-url');
	$('.table-ajax').DataTable({
		processing: true,
		serverSide: true,
		ajax: ajaxUrl,
		columns: [{
				data: 'created_at',
				name: 'created_at'
			},
			{
				data: 'customer',
				name: 'customer',
				orderable: false,
				searchable: false
			},
			{
				data: 'address',
				name: 'address',
				orderable: false,
				searchable: false
			},
			{
				data: 'amount',
				name: 'amount'
			},
			{
				data: 'view',
				name: 'view',
				orderable: false,
				searchable: false
			},
			{
				data: 'sent',
				name: 'sent',
				orderable: false,
				searchable: false
			}
		]
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/invoices/index.blade.php ENDPATH**/ ?>