<?php $__env->startSection('content'); ?>


<div class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Create New Role
                        </div>
                        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="panel-body">
                            <!-- New Team Form -->
                            <?php echo Form::open(array('class' => 'form-horizontal', 'files' => 'true')); ?>


                            <div class="form-group">
                                <?php echo Form::label('name', 'Role Name', array('class' => 'col-sm-3 control-label')); ?>

                                <div class="col-sm-6">
                                    <?php echo Form::text('name', '', array('class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-3 col-sm-9 add_btnn">
                                    <?php echo Form::submit('Add Role', array('class' => 'btn btn-primary')); ?>

                                </div>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>


                <?php if(count($roles) > 0): ?>
                <div class="card">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Roles
                        </div>

                        <div class="panel-body">
                            <table class="table table-striped task-table">

                                <!-- Table Headings -->
                                <thead>
                                    <th>Name</th>
                                    <th>&nbsp</th>
                                </thead>

                                <!-- Table Body -->
                                <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <!-- Task Name -->
                                        <td class="table-text">
                                            <div><?php echo e($role->name); ?></div>
                                        </td>


                                        <td>
                                            <form action="<?php echo e(url('role/'.$role->id)); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>


                                                <button class="btn btn-danger">
                                                    <i class="fa fa-trash"></i> Delete Role
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/roles/index.blade.php ENDPATH**/ ?>