
<?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::open(['route' => 'zipcodearea.store', 'class' => 'form-horizontal', 'method' => 'post']); ?>


<div class="form-group">
  <?php echo Form::label('zip_code', 'Zip Code', ['class' => 'col-xs-12 col-sm-6']); ?>

  <div class="col-xs-4">
    <?php echo Form::text('zip_code', null, ['class' => 'form-control']); ?>

  </div>
  <?php echo Form::label('area', 'Area', ['class' => 'col-xs-12 col-sm-1']); ?>

  <div class="col-xs-4">
  <?php echo Form::select('area', $area_select, 'NE', ['class' => 'form-control']); ?>

  </div>
  <div class="col-xs-2">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

  </div>
</div>

<?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/zip_code_areas/add.blade.php ENDPATH**/ ?>