<?php $x = 1; ?>

<h2>Add New Zip Code</h2>
<?php echo $__env->make('zip_code_areas.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<hr>
<h2>Current Zip Codes</h2>
<div class="row">
    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-xs-4 col-md-12 remove_space">
        <h5> <?php echo e($area); ?> </h5>
        <div style="background-color:lightgray; border:1px solid black; margin:3px; padding:6px 4px;">
            <?php $__currentLoopData = $zcas[$area]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($i->zip_code); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php if($x % 3 == 0): ?>
</div>
<div class="row">
    <?php endif; ?>
    <?php $x++ ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/zip_code_areas/grid.blade.php ENDPATH**/ ?>