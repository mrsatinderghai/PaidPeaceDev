<?php if(count($services) > 0): ?>
<table class="table table-condensed table-striped">
	<thead>
		<th>Category</th>
		<th>Description</th>
		<th>Cost</th>
		<th>Selling Price</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($service->category); ?></a></td>
			<td><a href="<?php echo e(url('service/'.$service->id.'/edit')); ?>"><?php echo e($service->description); ?></a></td>
			<td>$<?php echo e($service->cost); ?></td>
			<td>$<?php echo e($service->sell_price); ?></td>
			<td>
				<form action="<?php echo e(url('service/'.$service->id)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>


                <button class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                </button>
            </form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php endif; ?>
<?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/services/list.blade.php ENDPATH**/ ?>