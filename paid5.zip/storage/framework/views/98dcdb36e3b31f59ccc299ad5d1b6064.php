<?php $__env->startSection('content'); ?>

<script>
    $(function() {
        $("#from_date").datepicker({
            dateFormat: 'yy-mm-dd'
        });
        $("#to_date").datepicker({
            dateFormat: 'yy-mm-dd'
        });
    });
</script>



<div class="content-page">
    <div class="container-fluid payroll_report">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <?php echo Form::open(['route' => 'reports.finance.payroll']); ?>

                    <div class="col-xs-12 col-md-12">
                        <div class="form-group">
                            <?php echo Form::label('user_id', 'Employee'); ?>

                            <?php echo Form::select('user_id', $team_member_select, null, ['class' => 'form-control']); ?>

                        </div>
                    </div>
                    <div class="col-xs-12 col-md-12">
                        <div class="form-group">
                            <?php echo Form::label('from_date', 'From'); ?>

                            <?php echo Form::date('from_date', null, ['class' => 'form-control']); ?>

                        </div>
                    </div>
                    <div class="col-xs-12 col-md-12">
                        <div class="form-group">
                            <?php echo Form::label('to_date', 'To'); ?>

                            <?php echo Form::date('to_date', null, ['class' => 'form-control']); ?>

                        </div>
                    </div>
                    <div class="col-xs-12 col-md-12">
                        <div class="form-group">
                            <button class="btn btn-primary" class="form-control">Submit</button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
                <div class="card">
                    <h1 class="text-info">Payroll Report</h1>
                    <h3 class="text-primary"><?php echo e($name); ?></h3>
                    <h4 class="text-secondary"><?php echo e($from_date . " - " . $to_date); ?></h4>
                    <div class="table-responsive">
                        <table class="table table-striped table-condensed">
                            <tr>
                                <th>Invoice</th>
                                <th>Work Order</th>
                                <th>Customer</th>
                                <th>Labor Charge</th>
                                <th>Total Charge</th>
                                <th>Tender</th>
                            </tr>
                            <?php $__currentLoopData = $work_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr> </tr>
                            <td><?php echo e($wo->invoice->first()->id or ''); ?></td>
                            <td><?php echo e($wo->id); ?> <?php if($wo->shop_work): ?> <span class="bg-info">Shop Work</span> <?php endif; ?></td>
                            <td><?php echo e($wo->customer->full_name()); ?></td>
                            <?php
                            $ts = 0;
                            foreach($wo->services as $s) {
                            $ts += $s->pivot->line_cost;
                            }
                            ?>
                            <td>$<?php echo e(number_format($ts, 2)); ?></td>
                            <td><?php if($wo->invoice->first()): ?> $<?php echo e(number_format($wo->invoice->first()->amount, 2)); ?> <?php endif; ?></td>
                            <td><?php echo e($wo->invoice->first()->paid_with or ''); ?> <?php if($wo->invoice->first()): ?> (<?php echo e($wo->invoice->first()->transactions->first()->paid_with_detail or ''); ?>) <?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><b>Totals:</b></td>
                                <td></td>
                                <td></td>
                                <td><b>$<?php echo e(number_format($total_labor_charges, 2)); ?></b></td>
                                <td><b>$<?php echo e(number_format($total_charges, 2)); ?></b></td>
                                <td></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/reports/finance/payroll.blade.php ENDPATH**/ ?>