<?php if(count($products) > 0): ?>
<table class="table table-condensed table-striped">
	<thead>
		<th>Part No.</th>
		<th>Description</th>
		<th>Cost</th>
		<th>Selling Price</th>
		<th>On Hand</th>
		<th>On Order</th>
		<th></th>
		<th></th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($product->category); ?></a></td>
			<td><a href="<?php echo e(url('product/'.$product->id.'/edit')); ?>"><?php echo e($product->description); ?></a></td>
			<td>$<?php echo e($product->cost); ?></td>
			<td>$<?php echo e($product->sell_price); ?></td>
			<td>
				<form action="<?php echo e(url('product/update_inventory/'.$product->id)); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('PATCH')); ?>

					<input type="text" name="on_hand" value="<?php echo e($product->on_hand); ?>" size="4" />
			</td>
			<td>
					<input type="text" name="on_order" value="<?php echo e($product->on_order); ?>" size="4" />

			</td>
			<td>
					<button class="btn btn-info">
						<i class="fa fa-check"></i>
					</button>
				</form>
			</td>
			<td>
				<form action="<?php echo e(url('product/'.$product->id)); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('DELETE')); ?>


					<button class="btn btn-danger">
						<i class="fa fa-trash"></i>
					</button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php endif; ?>
<?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/products/list.blade.php ENDPATH**/ ?>