<?php $__env->startSection('content'); ?>
<div class="content-page">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="card">
					<div class="col-xs-6 part_head_sec">
						<h1>Services</h1>
					</div>
				</div>
				<div class="card">
					<div class="col-xs-12 col-md-6 part_section">
						<?php echo $__env->make('services.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<div class="col-xs-12 col-md-8">
						<?php echo $__env->make('services.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/services/index.blade.php ENDPATH**/ ?>