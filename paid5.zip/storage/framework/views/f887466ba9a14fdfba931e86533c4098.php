<div class="panel panel-default">
  <div class="panel-heading">
    New Truck
  </div>
  <div class="panel-body">
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo Form::model($truck, ['route' => 'truck.store', 'class' => 'form-horizontal']); ?>

    <div class="form-group">
      <?php echo Form::label('name', 'Name.', array('class' => 'col-sm-4 control-label')); ?>

      <div class="col-sm-8 remove_space">
        <?php echo Form::text('name', '', array('class' => 'form-control')); ?>

      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-4 col-sm-12 add_btnn">
        <?php echo Form::submit('Add', array('class' => 'btn btn-primary')); ?>

        <?php echo Form::close(); ?>

      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/trucks/add.blade.php ENDPATH**/ ?>