<?php $__env->startSection('content'); ?>
<div class="content-page">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="card ledger_sect">
					<div class="col-xs-6 col-md-6">
						<h1><?php echo e($title); ?></h1>
					</div>
					<div class="col-xs-6 col-md-6">
						<h3 align="right">$<?php echo e($balance); ?></h3>
					</div>
				</div>
				<div class="card">
					<div class="col-xs-12 col-md-6 part_section">
						<?php echo $__env->make('transactions.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>

					<div class="col-xs-12 col-md-8">
						<?php echo $__env->make('transactions.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/transactions/index.blade.php ENDPATH**/ ?>