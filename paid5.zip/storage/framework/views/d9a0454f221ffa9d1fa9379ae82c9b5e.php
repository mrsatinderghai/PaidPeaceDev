<div class="col-xs-12 col-md-10 sale_pipeline">
  <h1>Sales Pipeline</h1>
  <div class="row">
    <div class="col-xs-12 col-md-3">
      <h5>Pending</h5>
      <?php $__currentLoopData = $pending_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('sale/'.$sale->id)); ?>" class="btn btn-default btn-lg" style="margin-bottom: 5px;"><?php echo e($sale->name); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-xs-12 col-md-3">
      <h5>Waiting on Customer</h5>
      <?php $__currentLoopData = $awaiting_customer_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('sale/'.$sale->id)); ?>" class="btn btn-default btn-lg" style="margin-bottom: 5px;"><?php echo e($sale->name); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-xs-12 col-md-3">
      <h5>Proposal</h5>
      <?php $__currentLoopData = $proposal_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('sale/'.$sale->id)); ?>" class="btn btn-default btn-lg" style="margin-bottom: 5px;"><?php echo e($sale->name); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-xs-12 col-md-3">
      <h5>Accepted</h5>
      <?php $__currentLoopData = $accepted_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('sale/'.$sale->id)); ?>" class="btn btn-default btn-lg" style="margin-bottom: 5px;"><?php echo e($sale->name); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

</div>
<?php /**PATH C:\wamp64\www\paidpeaceten2\resources\views/sales/pipeline.blade.php ENDPATH**/ ?>