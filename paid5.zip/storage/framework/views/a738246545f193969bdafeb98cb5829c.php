<!-- Nav tabs -->


<ul class="nav nav-tabs" id="myTab-1" role="tablist">
	<li role="presentation" class="active">
		<a class="nav-link active" id="all-tab" data-toggle="tab" href="#all" role="tab" aria-controls="all" aria-selected="true">All</a>
	</li>
	<li class="presentation">
		<a class="nav-link" id="receivable-tab" data-toggle="tab" href="#receivables" role="tab" aria-controls="receivables" aria-selected="false">Receivable</a>
	</li>
	<li class="presentation">
		<a class="nav-link" id="payable-tab" data-toggle="tab" href="#payables" role="tab" aria-controls="payables" aria-selected="false">Payable</a>
	</li>
</ul>

<!-- Tab panes -->
<div class="tab-content">
	<div role="tabpanel" class="tab-pane show active" id="all" aria-labelledby="all-tab">
		<table class="table table-condensed table-striped">
			<thead>
				<th>Date</th>
				<th>Other Party</th>
				<th>Type</th>
				<th>Amount</th>
				<th></th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($transaction->date); ?></td>
					<td><?php echo e($transaction->other_party); ?></td>
					<td><?php echo e($transaction->type); ?></td>
					<td>
						<?php if($transaction->type == 'Payable'): ?> - <?php endif; ?>
						$<?php echo e($transaction->amount); ?>

					</td>
					<td>
						<form action="<?php echo e(url('transaction/'.$transaction->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('DELETE')); ?>


							<button class="btn btn-danger">
								<i class="fa fa-trash"></i>
							</button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>

	<div role="tabpanel" class="tab-pane fade" id="receivables" aria-labelledby="receivable-tab">
		<table class="table table-condensed table-striped">
			<thead>
				<th>Date</th>
				<th>Other Party</th>
				<th>Type</th>
				<th>Amount</th>
				<th></th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $receivables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($transaction->date); ?></td>
					<td><?php echo e($transaction->other_party); ?></td>
					<td><?php echo e($transaction->type); ?></td>
					<td>
						<?php if($transaction->type == 'Payable'): ?> - <?php endif; ?>
						$<?php echo e($transaction->amount); ?>

					</td>
					<td>
						<form action="<?php echo e(url('transaction/'.$transaction->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('DELETE')); ?>


							<button class="btn btn-danger">
								<i class="fa fa-trash"></i>
							</button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>

	<div role="tabpanel" class="tab-pane fade" id="payables" aria-labelledby="payable-tab">
		<table class="table table-condensed table-striped">
			<thead>
				<th>Date</th>
				<th>Other Party</th>
				<th>Type</th>
				<th>Amount</th>
				<th></th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $payables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($transaction->date); ?></td>
					<td><?php echo e($transaction->other_party); ?></td>
					<td><?php echo e($transaction->type); ?></td>
					<td>
						<?php if($transaction->type == 'Payable'): ?> - <?php endif; ?>
						$<?php echo e($transaction->amount); ?>

					</td>
					<td>
						<form action="<?php echo e(url('transaction/'.$transaction->id)); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('DELETE')); ?>


							<button class="btn btn-danger">
								<i class="fa fa-trash"></i>
							</button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>

</div><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/transactions/list.blade.php ENDPATH**/ ?>