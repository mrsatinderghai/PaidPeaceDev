<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="container-fluid Sharp_Mower">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="jumbotron">
            <div class="img-flex">
            <h1 style="position: relative; width: 100%">
            <?php echo e($team->name); ?>

            </h1>
            <img style="float: right; position: relative; height:45px;" class="img-responsive" src="<?php echo e(url($team->logo)); ?>" /><br />
            </div>           
            <?php echo e($team->address1); ?> <br />
            <?php if($team->address2 != null): ?>
            <?php echo e($team->address2); ?>

            <?php endif; ?>
            <?php echo e($team->city); ?>, <?php echo e($team->state); ?> <?php echo e($team->zip); ?><br />
            <a href="<?php echo e(url('team/'.$team->id.'/edit')); ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
          </>
        </div>
        <div class="card">


          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable-1" class="table data-table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $team_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <a href="<?php echo e(url('user/'.$member->id)); ?>"><?php echo e($member->name); ?></a>
                    </td>
                    <td>
                      <?php echo e($member->email); ?>

                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/teams/view.blade.php ENDPATH**/ ?>