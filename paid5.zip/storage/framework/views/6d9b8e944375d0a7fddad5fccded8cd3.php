<?php $__env->startSection('content'); ?>


<div class="content-page">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <?php echo $__env->make('sales.pipeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <hr />
        <div class="card">
          <div class="col-xs-12">
            <h3 class="ml-2 my-2">Tasks</h3>
            <?php echo $__env->make('tasks.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<script>
 localStorage.removeItem('activeMenu');
</script>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/home.blade.php ENDPATH**/ ?>