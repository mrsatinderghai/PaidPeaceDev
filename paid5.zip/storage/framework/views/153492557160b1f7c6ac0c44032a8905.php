<?php $__env->startSection('content'); ?>


<div class="content-page">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">				
				<div class="card">
				    <h4 class="m-3">Trucks</h4>
					<div class="col-xs-12 col-md-6 part_section">
						<?php echo $__env->make('trucks.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<div class="col-xs-12 col-md-12">
						<?php echo $__env->make('trucks.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\paidpeaceten\resources\views/trucks/index.blade.php ENDPATH**/ ?>