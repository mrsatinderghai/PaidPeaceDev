<table id="datatable-1" class="table data-table table-striped table-bordered table-ajax" data-url='{{isset($url)?$url:"/data/invoices/all"}}'>
	<thead>
		<th>Number</th>
		<th>Customer</th>
		<th>Date</th>
		<th>Status</th>
		<th>Amount</th>
		<th>View</th>
		<th>Checkout</th>
		<th>Delete</th>
	</thead>
	<tbody>

	</tbody>
</table>