@extends('layouts.master')
@section('content')

@include('work_orders.forms.add')

@endsection

