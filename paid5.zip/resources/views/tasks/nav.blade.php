<style>
	.nav_link
	{
		font-size: 20px;
		font-weight: light;
	}
</style>

<i class="fa fa-tasks fa-3x"></i><br/>
<a href="{{ url('/task/hot') }}" class="nav_link">Hot Tasks</a><br/>
<a href="{{ url('/task') }}" class="nav_link">My Tasks</a><br/>
<a href="{{ url('/task/team') }}" class="nav_link">Team Tasks</a><br/>
<!--<a href="{{ url('/task/project') }}" class="nav_link">Project View</a><br/>-->
